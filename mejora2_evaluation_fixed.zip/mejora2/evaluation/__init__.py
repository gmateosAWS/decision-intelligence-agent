"""
evaluation/
-----------
Observability and evaluation layer for the Decision Intelligence Agent.

Modules:
  observer   – AgentObserver: structured logging + per-run JSONL records
  metrics    – load_runs / compute_metrics helpers
  dashboard  – CLI report + self-contained HTML dashboard generator
"""

from .observer import AgentObserver
from .metrics import load_runs, compute_metrics

__all__ = ["AgentObserver", "load_runs", "compute_metrics"]
