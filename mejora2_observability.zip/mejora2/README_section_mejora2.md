---

## Observability & Evaluation Layer (`evaluation/`)

> Added in **Mejora 2**. Every agent run is captured, measured and visualisable.

### Architecture

```
app.py
  └─ AgentObserver.start_run(query)          ← opens a RunRecord
       ├─ planner_node  → obs.record_planner()
       ├─ tool_node     → obs.record_tool()
       └─ synthesizer_node → obs.record_synthesizer()
  └─ AgentObserver.end_run()                 ← writes to JSONL

logs/
  ├─ agent_runs.jsonl   ← one JSON record per run (append-only)
  ├─ agent.log          ← verbose debug log
  └─ dashboard.html     ← generated on demand
```

### Components

| Module | Responsibility |
|---|---|
| `evaluation/observer.py` | `AgentObserver` – wraps each run, records timing, derives confidence score, writes JSONL |
| `evaluation/metrics.py` | `load_runs` / `compute_metrics` – aggregates stats from JSONL; `print_report` – CLI summary |
| `evaluation/dashboard.py` | `generate_html_dashboard` – self-contained HTML with Chart.js; CLI entry point |

### RunRecord fields

| Field | Source | Description |
|---|---|---|
| `run_id` | observer | Unique ID per query (12-char hex) |
| `session_id` | observer | Groups runs within one `python app.py` session |
| `timestamp` | observer | ISO-8601 UTC |
| `query` | input | Raw user question |
| `action` | planner | `optimization` / `simulation` / `knowledge` |
| `reasoning` | planner | LLM's explanation of tool choice |
| `planner_latency_ms` | planner node | Time from entry to structured output |
| `tool_latency_ms` | tool node | Time to execute the analytical tool |
| `synthesizer_latency_ms` | synthesizer node | Time for natural-language response |
| `total_latency_ms` | observer | End-to-end wall time |
| `confidence_score` | observer | Derived: `1 – downside_risk_pct/100` for Monte Carlo, `1.0/0.3` for optimization, `0.9` for RAG |
| `raw_result_keys` | tool node | Dict keys returned by the tool |
| `success` | observer | `false` if any node raised an exception |
| `error` | observer | Exception message if `success=false` |
| `answer_length` | synthesizer | Character count of the final answer |

### LangSmith integration

Set these variables in `.env` to enable automatic tracing of every LangGraph invocation:

```env
LANGCHAIN_TRACING_V2=true
LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
LANGCHAIN_API_KEY=ls__your_key
LANGCHAIN_PROJECT=decision-intelligence-agent
```

`AgentObserver.langsmith_config()` injects `run_name`, `tags` and `metadata` so
each run appears named and tagged in the LangSmith UI. No code changes required —
tracing activates automatically when the env var is present.

### View metrics

**CLI report** (prints to terminal):

```bash
python -m evaluation.dashboard
```

**HTML dashboard** (opens in browser):

```bash
python -m evaluation.dashboard --out logs/dashboard.html
# then open logs/dashboard.html in your browser
```

**Inline (from the REPL)**:

```
Ask a business question: dashboard
```

The dashboard includes:
- KPI cards: total runs, success rate, avg latency, avg confidence
- Tool distribution doughnut chart
- Latency breakdown bar chart (planner / tool / synthesizer)
- Recent runs table with per-run confidence bars
- Error log (if any failures occurred)
