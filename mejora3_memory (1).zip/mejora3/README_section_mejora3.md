## Mejora 3 – Memoria Conversacional Multi-turno

### Objetivo

Dotar al agente de **memoria persistente entre turnos** y de un sistema de
**gestión de sesiones** que permite:

- Mantener el contexto de la conversación durante varios turnos dentro de la
  misma sesión.
- Reanudar sesiones anteriores después de reiniciar el proceso.
- Listar, explorar y borrar sesiones desde la CLI.

---

### Arquitectura: Memory Layer

```
app.py (REPL)
│
├── memory/
│   ├── __init__.py          ← exports públicos
│   ├── checkpointer.py      ← SqliteSaver singleton + agent_sessions table
│   └── session_manager.py   ← CRUD y listado de sesiones (CLI helpers)
│
├── agents/
│   ├── state.py             ← añade campo `history` (Annotated + operator.add)
│   ├── planner.py           ← inyecta últimos 3 turnos en el prompt LLM
│   └── workflow.py          ← build_graph(checkpointer=...) con persistencia
│
└── data/
    └── checkpoints.db       ← SQLite: tablas LangGraph + agent_sessions
```

---

### Componentes nuevos / modificados

#### `memory/checkpointer.py`

| Responsabilidad | Detalle |
|---|---|
| `get_checkpointer()` | Singleton `SqliteSaver` apuntando a `data/checkpoints.db` |
| `register_turn()` | Upsert en `agent_sessions`: actualiza `last_active` y `turn_count` |
| `_ensure_sessions_table()` | Crea la tabla `agent_sessions` si no existe |

Esquema de `agent_sessions`:

```
session_id  TEXT PRIMARY KEY
title       TEXT   -- primeros 60 chars de la primera query
created_at  TEXT   -- ISO 8601 UTC
last_active TEXT   -- ISO 8601 UTC, actualizado en cada turno
turn_count  INTEGER
```

#### `memory/session_manager.py`

```python
SessionManager.list_sessions()        # → List[dict]
SessionManager.get_session(sid)       # → dict | None
SessionManager.delete_session(sid)    # → bool
SessionManager.print_sessions()       # tabla numerada en stdout
SessionManager.session_info(sid)      # detalle de una sesión
```

#### `agents/state.py` (modificado)

```python
history: Annotated[List[Dict[str, str]], operator.add]
```

`operator.add` indica a LangGraph que los retornos de `history` de cada nodo
se **concatenan** en lugar de reemplazarse, acumulando todos los turnos.

#### `agents/planner.py` (modificado)

```python
_HISTORY_WINDOW = 3   # turnos anteriores inyectados en el prompt

messages = [system_prompt]
for turn in history[-_HISTORY_WINDOW:]:
    messages += [{"role": "user",      "content": turn["query"]},
                 {"role": "assistant", "content": turn["answer"]}]
messages.append({"role": "user", "content": current_query})
```

Esto permite referencias naturales entre turnos:
> *Usuario:* "¿Cuál es el precio óptimo?"
> *Usuario:* "¿Y si el precio fuese 28?" ← el planner entiende el contexto

#### `agents/workflow.py` (modificado)

- `build_graph(checkpointer=None)` acepta un `SqliteSaver` opcional.
- `synthesizer_node` devuelve `{"answer": ..., "history": [new_turn]}`.
  LangGraph aplica `operator.add` y el nuevo turno queda en el estado
  persistido bajo el `thread_id` de la sesión.

#### `app.py` (modificado)

Se añade gestión completa de sesiones en el REPL:

```
session new              # nueva sesión (nuevo thread_id)
session list             # lista de sesiones guardadas
session resume <id>      # reanudar por session_id completo
session resume <#>       # reanudar por índice de 'session list'
session info             # detalle de la sesión activa
session delete <id>      # elimina sesión del registro
dashboard                # métricas CLI + dashboard.html (Mejora 2)
exit                     # salir
```

El `thread_id` se pasa en el config de LangGraph:

```python
cfg["configurable"]["thread_id"] = session_id
result = graph.invoke({"query": raw, "run_id": run_id}, config=cfg)
```

---

### Flujo de un turno

```
Usuario escribe query
     │
     ▼
app.py: start_run() + build config {thread_id, observer}
     │
     ▼
graph.invoke()
  ├─ planner_node  → inyecta history[-3:] en prompt LLM
  ├─ tool_node     → ejecuta optimization / simulation / knowledge
  └─ synthesizer_node → genera answer + retorna {history: [new_turn]}
     │
     ▼
SqliteSaver persiste estado completo (historia acumulada)
     │
     ▼
register_turn() → upsert en agent_sessions
     │
     ▼
observer.end_run() → escribe logs/agent_runs.jsonl
```

---

### Dependencia nueva

```
langgraph-checkpoint-sqlite~=0.1
```

Añadir al final de `requirements.txt`.

---

### Ejemplo de sesión multi-turno

```
$ python app.py

  ● New session: 3f8a2c1d-…

Ask a business question: What price maximises profit?
  The optimization tool suggests a price of €24.50 …

Ask a business question: What if price is 20?
  At €20.00 the simulation shows expected profit of €8,400 …

Ask a business question: session list
  #   Session ID                           Turns  Last active           Title
  ─────────────────────────────────────────────────────────────────────────────
  1   3f8a2c1d-…                           2      2025-07-15 10:22:01   What price maximises pro

Ask a business question: session info
  Session ID   : 3f8a2c1d-…
  Title        : What price maximises profit?
  Created      : 2025-07-15T10:21:44+00:00
  Last active  : 2025-07-15T10:22:01+00:00
  Turn count   : 2

# --- Después de reiniciar ---

Ask a business question: session resume 1
  ● Resumed session: 3f8a2c1d-…

Ask a business question: And what about price 28?
  Building on previous context: at €28.00 profit is …
```

---

### Commit sugerido

```bash
git add memory/ agents/state.py agents/planner.py \
        agents/workflow.py app.py requirements.txt
git commit -m "feat: multi-turn conversational memory with SQLite checkpointing

- memory/__init__.py: exports get_checkpointer, register_turn, SessionManager
- memory/checkpointer.py: singleton SqliteSaver + agent_sessions table
- memory/session_manager.py: CRUD, listing, CLI helpers
- agents/state.py: add history field (Annotated + operator.add)
- agents/planner.py: inject last 3 turns into LLM prompt
- agents/workflow.py: build_graph(checkpointer=), synthesizer appends history
- app.py: session new/list/resume/info/delete commands
- requirements.txt: add langgraph-checkpoint-sqlite~=0.1
All lines within 88-char limit (black/ruff compliance)"
git push
```
